/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Soal;

import java.util.Scanner;

/**
 *
 * @author Mi
 */
public class Soal3 {
    public static void main(String[]args){
        Scanner inputan = new Scanner(System.in);
        
        String Nama,
        Nim,
        Semester,
        Kelas;
        
        System.out.println("Masukkan Nama: ");
        Nama = inputan.nextLine();
        System.out.println("Masukkan NIM: ");
        Nim = inputan.nextLine();
        System.out.println("Masukkan Semester: ");
        Semester = inputan.nextLine();
        System.out.println("Masukkan Kelas: ");
        Kelas = inputan.nextLine();
        System.out.println("-----Hasil-----");
        System.out.println("Nama: "+Nama);
        System.out.println("NIM: "+Nim);
        System.out.println("Semester: "+Semester);
        System.out.println("Kelas: "+Kelas);
        
    }
}
