/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo;

/**
 *
 * @author Mi
 */
public class Latihan3 {
    public static void main(String[]args){
        String matakuliah = "Pemrograman Berbasis Objek";
        String singkatan = "PBO";
        String sks = "3";
        String pengajar = "Didi Andriawan, S.Kom.";
        
        System.out.println("Matakuliah  : "+matakuliah);
        System.out.println("Singkatan   : "+singkatan);
        System.out.println("Jumlah SKS  : "+sks);
        System.out.println("Pengajar    : "+pengajar);
    }
}
