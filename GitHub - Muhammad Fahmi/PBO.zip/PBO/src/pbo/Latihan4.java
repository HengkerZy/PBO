/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo;

/**
 *
 * @author Mi
 */
public class Latihan4 {
    public static void main(String[]args){
        String Sistem_Operasi = "Windows 10 Pro", versi = "64 bit", pemilik = "Mi";
        
        System.out.println("Sistem Operasi  : "+Sistem_Operasi);
        System.out.println("Versi           : "+versi);
        System.out.println("Pemilik         : "+pemilik);
    }
}
