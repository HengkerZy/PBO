
import java.util.Scanner;
//Kode latihan praktikum: LATPRAK-06

/**
 *
 * @author Mi
 */
public class Latihan06 {
    public static void main(String [] args){
 
        Scanner inputan = new Scanner(System.in);
        System.out.println("Urutan Zodiak ke- ");
        int zodiak = inputan.nextInt();
        System.out.println("");
        
        switch (zodiak){
            case 0:
                System.out.println("Urutan Zodiak ke-" + zodiak + " adalah Aries");
                break;
            case 1:
                System.out.println("Urutan Zodiak ke-" + zodiak + " adalah Capricorn");
                break;
            case 3:
                System.out.println("Urutan Zodiak ke-" + zodiak + " adalah Aquarius");
                break;
            case 4:
                System.out.println("Urutan Zodiak ke-" + zodiak + " adalah Pisces");
                break;
            case 5:
                System.out.println("Urutan Zodiak ke-" + zodiak + " adalah Taurus");
                break;
            case 6:
                System.out.println("Urutan Zodiak ke-" + zodiak+ " adalah Gemini");
                break;
            case 7:
                System.out.println("Urutan Zodiak ke-" + zodiak+ " adalah Cancer");
                break;
            case 8:
                System.out.println("Urutan Zodiak ke-" + zodiak+ " adalah Leo");
                break;
            case 9:
                System.out.println("Urutan Zodiak ke-" + zodiak+ " adalah Virgo");
                break;
            case 10:
                System.out.println("Urutan Zodiak ke-" + zodiak+ " adalah Libra");
                break;
            case 11:
                System.out.println("Urutan Zodiak ke-" + zodiak+ " adalah Scorpio");
                break;
            case 12:
                System.out.println("Urutan Zodiak ke-" + zodiak+ " adalah Sagitarius");
                break;
            default:
                System.out.println("Tidak ada Zodiak ke-" + zodiak);
        }
    }
}
