
import java.util.Scanner;
//Kode latihan praktikum: Latihan

/**
 *
 * @author Mi
 */
public class Latihan05 {
    public static void main(String[] args) {
        
        Scanner avg = new Scanner(System.in).useDelimiter("\n");
        System.out.print("Masukkan nilai huruf untuk rata-rata: ");
        int a = avg.nextInt();
        
        if(a >=0 && a <= 45) {
            System.out.println("Nilai = E");
        }else if(a >= 45 && a <= 54) {
            System.out.println("Nilai = D");
        }else if(a >= 55 && a <= 64) {
            System.out.println("Nilai = C");
        }else if(a >= 65 && a <= 79) {
            System.out.println("Nilai = B");
        }else if(a >= 80 && a <= 100) {
            System.out.println("Nilai = A");
        }
    }
}