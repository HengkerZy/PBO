/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author Mi
 */
public class L4_InputKeyboard_1 {
    public static void main(String[]args){
        Scanner biodata = new Scanner(System.in);
        
        System.out.println("Masukkan Nama: ");
        String nama = biodata.nextLine();
        System.out.println("Masukkan Program Studi: ");
        String studi = biodata.nextLine();
        System.out.println("Masukkan Nama Kampus: ");
        String kampus = biodata.nextLine();
        System.out.println("Masukkan Nama Fakultas: ");
        String fakultas = biodata.nextLine();
        System.out.println("-------Hasil-------");
        
        System.out.println("Nama: "+nama);
        System.out.println("Program Studi: "+studi);
        System.out.println("Nama Kampus: "+kampus);
        System.out.println("Nama Fakultas: "+fakultas);
    }
}
