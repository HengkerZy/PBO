
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mi
 */
public class L_Kelulusan2 {
    public static void main(String[] args) {
        //Buat Scanner
        Scanner inp = new Scanner(System.in);
        
        //Ambil Nama
        System.out.println("Masukkan nama anda = ");
        String nama = inp.next();
        
        //Ambil NIM
        System.out.println("Masukkan NIM = ");
        String nim = inp.next();
        
        //Ambil Nilai
        System.out.println("Masukkan Nilai = ");
        float nilai = inp.nextFloat();
        
        //Print
        if(nilai < 3.00) {
            System.out.println("Cukup");
        } else if(nilai < 3.49) {
            System.out.println("Memuaskan");
        } else if(nilai < 3.74) {
            System.out.println("Sangat Memuaskan");
        } else {
            System.out.println("Cum Laude");
        }
    }
}
