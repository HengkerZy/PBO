/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 *
 * @author Mi
 */
public class L4_InputKeyboard_2 {
    public static void main(String[] args) {
        
        BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
        
        try {
            System.out.println("Input nilai pertama: ");
            int nilai1 = Integer.parseInt(br1.readLine());
            
            System.out.println("Input nilai kedua: ");
            int nilai2 = Integer.parseInt(br1.readLine());
            int hasil = nilai1 + nilai2;
            
            System.out.println("Hasil penjumlahan "+nilai1+" dengan "+nilai2+" adalah "+hasil);
            
            
        } catch (IOException ex) {
            System.out.println("Error pada saat input data");
        }
    }
}
