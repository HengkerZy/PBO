
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mi
 */
public class L_Kelulusan1 {
    public static void main(String[] args) {
        //Buat Scanner
        Scanner inp = new Scanner(System.in);
        
        //Ambil Nama
        System.out.println("Masukkan nama anda = ");
        String nama = inp.next();
        
        //Ambil NIM
        System.out.println("Masukkan NIM = ");
        String nim = inp.next();
        
        //Ambil Nilai
        System.out.println("Masukkan Nilai = ");
        int nilai = inp.nextInt();
        
        //Print
    if(nilai > 65) {
        System.out.println("Anda lulus ");
    } else {
        System.out.println("Anda tidak lulus ");
    }
    }
}
