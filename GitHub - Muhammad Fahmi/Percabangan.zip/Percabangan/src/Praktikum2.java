/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;

/**
 *
 * @author Mi
 */
public class Praktikum2 {

    public static void main(String[] args) {

        Scanner cabang = new Scanner(System.in);
        System.out.println("Masukkan nilai pertama: ");
        int nilai1 = cabang.nextInt();

        System.out.println("Masukkan nilai kedua: ");
        int nilai2 = cabang.nextInt();

        System.out.println("Masukkan nilai ketiga: ");
        int nilai3 = cabang.nextInt();

        if (nilai1 > nilai2 && nilai1 > nilai3) {
            System.out.println("Nilai 1 yang terbesar");
        } else if (nilai2 > nilai1 && nilai2 > nilai3) {
            System.out.println("Nilai 2 yang terbesar");
        } else if (nilai3 > nilai1 && nilai3 > nilai2) {
            System.out.println("Nilai 3 yang terbesar");
        } else {
            System.out.println("Semua nilai sama besarnya");
        }
    }
}
