/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;

/**
 *
 * @author Mi
 */
public class Praktikum1 {
    public static void main(String[] args) {

        Scanner cabang = new Scanner(System.in);
        System.out.println("Masukkan nilai pertama: ");
        int nilai1 = cabang.nextInt();
        System.out.println("Masukkan nilai kedua: ");
        int nilai2 = cabang.nextInt();
        
        if(nilai1 < nilai2) {
            System.out.println("Nilai pertama lebih kecil daripada nilai kedua");
        } else {
            System.out.println("Nilai pertama lebih besar daripada nilai kedua");
        }
    }
}
