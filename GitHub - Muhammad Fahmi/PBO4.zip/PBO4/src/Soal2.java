
import java.util.Scanner;

/**
 *
 * @author Mi
 */
public class Soal2 {
    public static void main(String [] args){
 
        Scanner input = new Scanner(System.in);
        System.out.println("Masukkan Bulan ke- ");
        int bulan = input.nextInt();
        System.out.println("");
        
        switch (bulan){
            case 1:
                System.out.println("Bulan ke-" + bulan + " adalah Januari");
                break;
            case 2:
                System.out.println("Bulan ke-" + bulan + " adalah Februari");
                break;
            case 3:
                System.out.println("Bulan ke-" + bulan + " adalah Maret");
                break;
            case 4:
                System.out.println("Bulan Ke-" + bulan + " adalah April");
                break;
            case 5:
                System.out.println("Bulan ke-" + bulan + " adalah Mei");
                break;
            case 6:
                System.out.println("Bulan ke-" + bulan + " adalah Juni");
                break;
            case 7:
                System.out.println("Bulan Ke-" + bulan + " adalah Juli");
                break;
            case 8:
                System.out.println("Bulan Ke-" + bulan + " adalah Agustus");
                break;
            case 9:
                System.out.println("Bulan Ke-" + bulan + " adalah September");
                break;
            case 10:
                System.out.println("Bulan Ke-" + bulan + " adalah Oltober");
                break;
            case 11:
                System.out.println("Bulan Ke-" + bulan + " adalah November");
                break;
            case 12:
                System.out.println("Bulan Ke-" + bulan + " adalah Desember");
                break;
            default:
                System.out.println("Tidak ada Bulan ke-" + bulan);
        }
    }
}
