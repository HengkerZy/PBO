
import java.util.Scanner;

/**
 *
 * @author Mi
 */
public class Latihan7 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Siapakah Presiden pertama Indonesia?");
        System.out.println("A. Dr. Ir. H. Soekarno");
        System.out.println("B. B.J. Habibie");
        System.out.println("C. Megawati Soekarno Putri");
        System.out.println("D. Abdurrahman Wahid");
        char pilih = scan.next().charAt(0);
        
        switch(pilih) {
            case 'A':
                System.out.println("Benar!");
                break;
            case 'B':
                System.out.println("Salah, jawabannya adalah Dr. Ir. H. Soekarno");
                break;
            case 'C':
                System.out.println("Salah, jawabannya adalah Dr. Ir. H. Soekarno");
                break;
            case 'D':
                System.out.println("Salah, jawabannya adalah Dr. Ir. H. Soekarno");
                break;
            default:
                System.out.println("Sistem Error");
        }
    }
}
