/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mi
 */
public class Soal1 {
    public static void main(String [] args){
        double d = 1.2345;
        short s = (short) d;
        
        System.out.println("Nilai d = " +d);
        System.out.println("Nilai s = " +s);
       
    }
}
