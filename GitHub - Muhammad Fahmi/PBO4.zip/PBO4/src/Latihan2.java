
import java.util.Scanner;

/**
 *
 * @author Mi
 */
public class Latihan2 {
    public static void main(String[] args) {
        
        int belanja = 0;
        Scanner scan = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Total Belanjaan: Rp ");
        belanja = scan.nextInt();
        
        if(belanja > 100000) {
            System.out.println("Selamat, Anda mendapatkan diskon!");
        }
        System.out.println("Terima Kasih");
    }
}
