
import java.util.Scanner;

/**
 *
 * @author Mi
 */
public class Latihan4 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Apakah anda Mahasiswa Poliban? (Y jika benar)");
        String jawaban = scan.next();
        
        if("Y".equals(jawaban)) {
            System.out.println("Selamat berjuang di Poliban!");
        } else {
            System.out.println("Selamat datang di Poliban");
        }
    }
}
